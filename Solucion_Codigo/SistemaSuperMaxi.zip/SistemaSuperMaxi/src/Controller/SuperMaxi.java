package Controller;

import java.util.ArrayList;

public class SuperMaxi {
    public ArrayList<Producto> producto;
    
    public SuperMaxi(ArrayList<Producto> producto) {
        this.producto = producto;
    }
}