package Controller;

public enum CategoriaProducto {
    VIVIENDA,
    EDUCACION,
    ALIMENTACION,
    VESTIMENTA,
    SALUD
}
